% Hua-sheng XIE, huashengxie@gmail.com, IFTS-ZJU, 2012-03-03 20:34
% fkvl1d.m, 1D full-kinetic Vlasov code for unmagnetized plasma
% ion immobile, periodical boundary condition, phi(1)=phi(Nx+1)=0
close all;clear;clc;

% Landau damping data
data = [0.1   1.0152   -4.75613E-15
0.2   1.06398   -5.51074E-05
0.3   1.15985   -0.0126204
0.4   1.28506   -0.066128
0.5   1.41566   -0.153359
0.6   1.54571   -0.26411
0.7   1.67387   -0.392401
0.8   1.7999   -0.534552
0.9   1.92387   -0.688109
1.0   2.0459   -0.85133
1.5   2.63233   -1.77571
2   3.18914   -2.8272];
id=6;

k=data(id,1); wr=data(id,2); gamma=data(id,3);

nx=1*32; nv=2*64; dt=0.01; nt=5000/2; % parameters
L=2*pi/k; vmax=8.0; vmin=-vmax;
dx=L/nx; dv=(vmax-vmin)/nv;
fperp=0.1;

na=1.0; nb=1.0-na; vta=1.0; vtb=1.0; vda=-0.0; vdb=2.0;
% na=0.5; nb=1.0-na; vta=0.5; vtb=0.5; vda=-2.0; vdb=2.0;
% na=0.9; nb=1.0-na; vta=1.0; vtb=0.5; vda=-0.0; vdb=4.0;

vta=sqrt(2);

if(na==1.0)  % for plot Landau damping theoretical results
    tt=20;
else
    tt=0;
end

X=0:dx:L; V=vmin:dv:vmax; [v,x]=meshgrid(V,X); % x and v grids
f=na*exp(-(v-vda).^2/(vta^2))/(sqrt(pi)*vta)+...
    nb*exp(-(v-vdb).^2/(vtb^2))/(sqrt(pi)*vtb); % initial distribution
f=(1.0+fperp.*cos(k.*x)).*f; % initial perturbation

f(:,1)=0; f(:,nv+1)=0; % boundary in V space F must be null
f(nx+1,:)=f(2,:); % boundary in X space are periodic
f(1,:)=f(nx,:);

% f=f./(sum(sum(f))*dx*dv)/L; % re-normalized to avoid discete errors
fv0=sum(f,1)*dx; maxfv0=max(fv0);

rho_back=1.0; % /L

dtodx=dt/dx; dtodv=dt/dv; dx2=dx*dx;

un=ones(nx,1);
poisson=spdiags([un -2*un un],[-1 0 1],nx,nx);
poisson(1,nx)=1;poisson(nx,1)=1; % phi(nx+1)=phi(1), phi(0)=phi(nx)

figure('position',[100 100 800 600]);
set(gcf,'DefaultAxesFontSize',15);
set(gca,'nextplot','replacechildren');
ifig=1;

for it=1:nt
    
    rho=sum(f,2)*dv-rho_back; % computing density
    
    phi=poisson\(rho(1:nx)*dx2); % computing fields
    phi=[phi;phi(1)]; % ./rho_back
    Ex=([phi(nx+1); phi(1:nx)]-[phi(2:nx+1);phi(1)])/(2*dx);
    Ex(nx+1)=Ex(1);
    
    for j=2:nv % computing PDF
        f(1,j)=f(1,j)-V(j)*(f(2,j)-f(nx,j))/2*dtodx+...
                Ex(1)*(f(1,j+1)-f(1,j-1))/2*dtodv;
        for i=2:nx
            f(i,j)=f(i,j)-V(j)*(f(i+1,j)-f(i-1,j))/2*dtodx+...
                Ex(i)*(f(i,j+1)-f(i,j-1))/2*dtodv;
        end
    end
    
    f(:,1)=0; f(:,nv+1)=0; % boundary in V space F must be null
    f(nx+1,:)=f(1,:); % boundary in X space are periodic
    
    den=sum(f,2)*dv; % density
    P=sum(v.*f,2)*dv; % momentum
    Ek=sum((v.^2).*f,2)*dv; % kinetic energy
    t(it)=it*dt;
    Den=sum(den); % density history
    PP(it)=sum(P); % momentum history
    EEk(it)=sum(Ek); % kinetic energy history
    EEf(it)=0.5*sum(Ex.*Ex)*dx; % field energy history
    
    if(mod(it,floor(nt/200)*10)==0) % diagnose
        pause(0.001);
        
        subplot(2,2,1:2); 
        colormap(hot);
        [C,h] =contourf(x,v,f,50); colorbar;
        set(h,'Color','none');
        title(['(a) f(x,v), t=',num2str(it*dt),'(',num2str(nt*dt),...
            ')\omega_{pe}^{-1}, k=',num2str(k)],'fontsize',15);
        xlabel('x');ylabel('v');

        subplot(2,2,3);
        fv=sum(f,1)*dx;
        plot(v,fv0,'--',v,fv,'-','LineWidth',2); grid on;
        title('(b) f(v,t)');xlabel('v');ylabel('f');
        ylim([0,1.2*maxfv0]);xlim([vmin,vmax]);

        subplot(2,2,4);
        plot(v,fv-fv0,'-',[vmin,vmax],[0,0],'--','LineWidth',2);
        title('(c) \delta{}f(v,t)');xlabel('v');ylabel('\delta{}f');
        xlim([vmin,vmax]);
        ylim([-1*fperp*maxfv0,1*fperp*maxfv0]);
        ylim([-1*fperp,1*fperp]);
        
        Fig(ifig)=getframe(gcf,[0,0,800,600]);
        ifig=ifig+1;
    end
end
print(gcf,'-dpng','plot_fxv.png');
movie(Fig);
writegif('movie_fxv.gif',Fig,0.1);
% close all;

%%
h = figure;
set(gcf,'DefaultAxesFontSize',15);
subplot(221);plot(t,PP-mean(PP),'LineWidth',2); xlim([0,max(t)]);
title('(a) Momentum v.s. Time','fontsize',15);xlabel('t');ylabel('P-<P>');
subplot(222);plot(t,Den-mean(Den),'r','LineWidth',2); xlim([0,max(t)]);
title('(b) Density v.s. Time','fontsize',15);xlabel('t');ylabel('n-<n>');
subplot(223);
semilogy(t,EEk,t,EEf,t,EEk+EEf,':','LineWidth',2);
title(['(c) k=',num2str(k),', \omega_{theory}=',...
    num2str(wr+1i*gamma)],'fontsize',15);
xlabel('t');ylabel('Energy');legend('E_k','E_e','E_{tot}',4);
legend('boxoff'); xlim([0,max(t)]);

subplot(224);
% Find the corresponding indexes of the extreme max values 
lndE=log(sqrt(real((EEf(1:nt))))); % EEf=E^2=[exp(gam*t)]^2=exp(2*gam*t)
it0=floor(nt*1/20); it1=floor(nt*7/20);
yy=lndE(it0:it1);
extrMaxIndex = find(diff(sign(diff(yy)))==-2)+1;
t1=t(it0+extrMaxIndex(1));t2=t(it0+extrMaxIndex(end));
y1=yy(extrMaxIndex(1));y2=yy(extrMaxIndex(end));
plot(t,lndE,[t1,t2],[y1,y2],'r*--','LineWidth',2);
omega=pi/((t2-t1)/(length(extrMaxIndex)-1));
gammas=(real(y2)-real(y1))/(t2-t1);
title(['(d) \omega^S=',num2str(omega),', \gamma^S=',num2str(gammas)]);
axis tight;

print(h,'-dpng','plot_diag.png');
% close all;
