n(1)=0.01;
u(1)=0;
E(1)=0;
tmp=10;
dt=0.01/tmp;
nt=1000*tmp;
k=2;
t(1)=0;
for it=1:nt
   n(it+1)=n(it)-1i*k*u(it)*dt;
   u(it+1)=u(it)-(E(it)+3*1i*k*n(it))*dt;
   E(it+1)=-n(it)/(1i*k);
   t(it+1)=t(it)+dt;
end
plot(t,real(n));