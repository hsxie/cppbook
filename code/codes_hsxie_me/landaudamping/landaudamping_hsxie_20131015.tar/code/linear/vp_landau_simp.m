close all; clear; clc;
k=0.4; dt=0.01; nt=8000; dv=0.1; vv=-8:dv:8;
df0dv=-vv.*exp(-vv.^2./2)/sqrt(2*pi); df=0.*vv+0.1.*exp(-(vv-2.0).^2);
tt=linspace(0,nt*dt,nt+1); dE=zeros(1,nt+1); dE(1)=0.01;
for it=1:nt
    df=df+dt.*(-1i*k.*vv.*df+dE(it).*df0dv);
    dE(it+1)=(1i/k)*sum(df)*dv;
end
figure('DefaultAxesFontSize',15);
plot(tt,real(dE),'LineWidth',2); xlabel('t'); ylabel('Re(dE)');
