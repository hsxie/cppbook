% Hua-sheng XIE, huashengxie@gmail.com, IFTS-ZJU, 2011-11-26
% zoncappcf_fun.m, solve Eq.(23), for zoncappcf_main.m & faddeev.m
% [Zonca1996] Zonca, F.; Chen, L. & Santoro, R. A., Kinetic theory of
% low-frequency Alfv��n modes in tokamaks, Plasma Physics and Controlled
% Fusion, 1996, 38, 2011.
% Eq.(23): ��^2=(qRk)^2
function ff=zoncappcf_fun(w)
    global dwk
    sym w;
    
    betai=dwk.betai;wti=dwk.wti;wni=dwk.wni;tau=dwk.tau;q=dwk.q;
    wpi=dwk.wpi;
    
    qRk=dwk.qRk;
    
    zeta=@(x)faddeeva(x)*1i*sqrt(pi);
    
    F=w*(w^2+3/2)+(w^4+w^2+1/2)*zeta(w);
    G=w*(w^4+w^2+2)+(w^6+w^4/2+w^2+3/4)*zeta(w);
    N=(1-wni/w)*(w+(1/2+w^2)*zeta(w))-wti/w*(w*(1/2+w^2)+(1/4+w^4)*zeta(w));
    D=(1+1/tau)/w+(1-wni/w)*zeta(w)-wti/w*(w+(w^2-1/2)*zeta(w));
    
	ff=w^2*(1-wpi/w)+q^2*w*((1-wni/w)*F-wti/w*G-N^2/D)...
        -(qRk)^3/abs(qRk)/betai;
