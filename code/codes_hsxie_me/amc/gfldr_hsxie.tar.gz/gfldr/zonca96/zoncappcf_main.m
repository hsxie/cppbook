% Hua-sheng XIE, huashengxie@gmail.com, IFTS-ZJU, 2011-11-26
% zoncappcf_main.m, solve Eq.(23), need zoncappcf_fun.m & faddeev.m
% [Zonca1996] Zonca, F.; Chen, L. & Santoro, R. A., Kinetic theory of
% low-frequency Alfv��n modes in tokamaks, Plasma Physics and Controlled
% Fusion, 1996, 38, 2011.
% Eq.(23): ��^2=(qRk)^2
close all;clear;clc;

global dwk

etai_list=[0.0,0.25,0.5];
for ieta=1:length(etai_list)
    etai=etai_list(ieta);
    
    betai=0.01;wni=1.0;tau=1.0;q=1.5;
    wti=etai*wni;wpi=wti+wni;

    dwk.betai=betai;dwk.wti=wti;dwk.wni=wni;dwk.q=q;dwk.tau=tau;
    dwk.wpi=wpi;

    w=[];
    qRk=-0.2:0.02:0.2;
    [row,col]=size(qRk);

    x0=(1.2-0.5i); % initial guess: BAE, x0=(2.5-0.5i); KBM, x0=(1.2-0.5i).

    for jk=1:col
        dwk.qRk=qRk(jk);
        warning off;
        options=optimset('Display','off');
        [x,fval]=fsolve(@zoncappcf_fun,x0,options);
        if(fval<10^(-4))
            w=[w;x];
            wr=real(w);wi=imag(w);  % wr, numerical solution of omega real
            x0=x;
        end
    end

    plot(wr(1:end/2),wi(1:end/2),'bo--',wr(end/2+1:end),wi(end/2+1:end),'gs--','LineWidth',2);
    text(wr(end/2),wi(end/2),['\eta_i=',num2str(etai)],'FontSize',18);
    hold on;
end

title(['General Fishbone Like Dispersion Relation, q=',num2str(q),', \tau=',...
    num2str(tau),', \beta_i=',num2str(betai),', \Omega_{*ni}=',num2str(wni)]);
xlabel('Re(\Omega)');ylabel('Im(\Omega)');