% Hua-sheng XIE, huashengxie@gmail.com, IFTS-ZJU, 2011-11-26
% gfldr_fun.m, solve gfldr, for gfldr_main.m & faddeev.m
% [Zonca2009] Zonca, F.; Chen, L.; Botrugno, A.; Buratti, P.; Cardinali,
% A.; Cesario, R.; Ridolfini, V. P. & contributors, J.-E., High-frequency
% fishbones at JET: theoretical interpretation of experimental
% observations, Nuclear Fusion, 2009, 49, 085009.
function ff=gfldr_fun(w) % Mirror mode, C_MM=0
    global dwk
    sym w;
    
    wTi=dwk.wTi;wni=dwk.wni;tau=dwk.tau;q=dwk.q;
    wpi=dwk.wpi;
        
    zeta=@(x)faddeeva(x)*1i*sqrt(pi);
    
    F=w*(w^2+3/2)+(w^4+w^2+1/2)*zeta(w);
    G=w*(w^4+w^2+2)+(w^6+w^4/2+w^2+3/4)*zeta(w);
    N=(1-wni/w)*(w+(1/2+w^2)*zeta(w))-(wTi/w)*(w*(1/2+w^2)+(1/4+w^4)*zeta(w));
    D=(1+1/tau)/w+(1-wni/w)*zeta(w)-(wTi/w)*(w+(w^2-1/2)*zeta(w));
    
    ff=w^2*(1-wpi/w)+q^2*w*((1-wni/w)*F-wTi/w*G-N^2/D);
%     ff=w*(1-wpi/w)+q^2*((1-wni/w)*F-wTi/w*G-N^2/D);


