% Hua-sheng XIE, huashengxie@gmail.com, IFTS-ZJU, 2011-11-26
% gfldr_main.m, solve gfldr, need gfldr_fun.m & faddeev.m
% [Zonca2009] Zonca, F.; Chen, L.; Botrugno, A.; Buratti, P.; Cardinali,
% A.; Cesario, R.; Ridolfini, V. P. & contributors, J.-E., High-frequency
% fishbones at JET: theoretical interpretation of experimental
% observations, Nuclear Fusion, 2009, 49, 085009.
close all;clear;clc;

global dwk

% parameters from [Zonca2009]
q=1;m=1;etai=1.6;
R0=3.0; % m
rs=0.31; % m
B=2.7; % T
Te=4.9; % keV
Ti=3.0:0.2:6.0; % keV
tau=Te./Ti;
mi=1.6726e-27; % kg
e=1.6022e-19; % C
kb=1.3807e-23;
kbe=e/kb*1e3; % keV to K
c=2.99792458e8; % m/s
gradni=4.4; % -R0*dr(ln(ni))
wti=sqrt((Ti.*kbe*kb)./mi)./(q*R0);
B_theta=B*q*R0/sqrt((q*R0)^2+rs^2);
B_psi=B_theta*rs/(q*R0);
% wni=((Ti.*kbe*kb)./(e*B)).*gradni/R0*((m/rs)*(B_theta/B)-1/(2*pi*R0)*B_ps
% i);
wni=((Ti.*kbe*kb)./(e*B)).*gradni/R0*(m/rs);
wTi=wni.*etai;
wpi=wni+wTi;
wbae=q.*wti.*sqrt(7/4+tau);

w=[];
[row,col]=size(Ti);

x0=(2.5+0.1i); % initial guess

for jk=1:col

    dwk.q=q;
    dwk.wTi=wTi(jk)/wti(jk);dwk.wni=wni(jk)/wti(jk);dwk.tau=tau(jk);
    dwk.wpi=wpi(jk)/wti(jk);
    
    warning off;
    options=optimset('Display','off');
    [x,fval]=fsolve(@gfldr_fun,x0,options);
    if(fval<10^(-4))
        w=[w;x];
        wr=real(w);wi=imag(w);  % wr, numerical solution of omega real
        x0=x;
    end
end

close all;

col1=Ti';
col2=(wni./wti)';
col3=(wpi./(2*pi))';
col4=(wbae./(2*pi))';
col5=wr;
col6=wi;
col7=(wr.*wti'./(2*pi));

table=[col1,col2,col3,col4,col5,col6,col7];

% figure('unit','normalized','Position',[0.1 0.5 0.7 0.4],...
%             'Name','General Fishbone Like Dispersion Relation',... % 'menubar','none',...
%             'NumberTitle','off');

% plot(wr,wi,'ro--','LineWidth',2);
% title(['General Fishbone Like Dispersion Relation, q=',num2str(q),', \eta_i=',...
%     num2str(etai),', Te=',num2str(Te)]);
% xlabel('Re(\Omega)');ylabel('Im(\Omega)');

