% Hua-sheng XIE, IFTS-ZJU, huashengxie@gmail.com, 2012-12-31 13:16
% AWCON.m, calculate ideal MHD Alfven Wave CONtinuum spectral in tokamak
% See also: 1. ALCON code by Wenjun DENG (UCI, 2012);
%           2. NOVA code in PPPL (C.Z.Cheng, 1986).
% Note: AWCON.m and ALCON solve only the continuum spectral, not eigenmodes
%       (AEs), e.g., TAE, BAE, EAE, NAE, RSAE, ...
%       NOVA is more general: equilirium (Jsolver), continuum spetral, 
%       eigenmodes, kinetic energetic particle effect, ...
% 2013-01-01 02:16 draft version OK
% 2013-01-25 10:39 add finitebeta option
% 2013-03-12 15:08 fixed the bug for finitebeta=2 and 3, test OK now
close all; clear; clc;
runtime=cputime;

% equilibrium selection
eq=1; % only simple analytical equilibrium in this version
rho=0.0:0.002:1.0;
nrad=length(rho);
aminor=0.334862658413864; R0=1.0;
if(eq==1)
    % read profile data, test Wen-jun's RSAE
    profile_sa=importdata('profile_sa.dat',' ',2);
    rho_tmp=profile_sa.data(:,1); % radius
    q_tmp=profile_sa.data(:,2); % safety factor
    beta_tmp=profile_sa.data(:,3); % beta=4*pi*gamma*P0/Ba^2
    rho_M_tmp=profile_sa.data(:,4); % mass density
    q=interp1(rho_tmp,q_tmp,rho,'spline');
    beta=interp1(rho_tmp,beta_tmp,rho,'spline');
    rho_M=interp1(rho_tmp,rho_M_tmp,rho,'spline');
else
    aminor=0.4; R0=1.65;
    q=1.1+3.5*(rho-0.0).^4;
    beta=-0.01*rho.^4+0.03;
    rho_M=-0.9*rho.^4+1;
end

figure('Unit','Normalized','Position',[0.01 0.42 0.6 0.5]);
set(gcf,'DefaultAxesFontSize',15);
subplot(221);
B=1-rho.*(aminor/R0)+(rho.*(aminor/R0)).^2/2.*(1./q.^2+1);
va=B./sqrt(rho_M);
plot(rho,q,rho,beta,rho,rho_M,rho,B,'--',rho,va,':','LineWidth',2); 
xlabel('r/a');
legend('q','\beta','\rho_M','B','v_A'); legend('boxoff');

finitebeta=3;
% finitebeta = 0: pure Alfven continua, no acoustic coupling, not yet or
%                 set noffdiag=0
% finitebeta = 1: Alfven continua with acoustic coupling with slow sound
% finitebeta = 2: pure sound continua
% finitebeta = 3: accurate Alfven continua with acoustic coupling
for ifbeta=1:3
    finitebeta=ifbeta;
    
noffdiag=20;
n=4; % toroidal mode nubmer
m1=-20; m2=47; % poloidal mode number m solving in [m1, m2]
Ndim1=(m2-m1+1);
Ndim=(1+(finitebeta>2))*Ndim1;

%% simple analytic equilibrium, alcon_eqdata.F90
r=rho.*aminor;
epsilon=rho.*aminor/R0;
g=1.0-epsilon.^2/2.0;
I=epsilon.^2./2+epsilon.^4./(2.*q);
D=g.*q+I;

% matrix H
H=(epsilon./q).^2./(g.*q+I);
Hft=zeros(Ndim1,nrad);
Hft(1,:)=H; % only m=0 Fourier mode

% matrix J
Jtmp=(epsilon./q).^2.*D;
Jft=zeros(Ndim1,nrad);
Jft(1,:)=(1+epsilon.^2.*(3-2./q.^2)).*Jtmp;
Jft(2,:)=2.*epsilon.*Jtmp;
Jft(3,:)=2.5.*epsilon.^2.*Jtmp;

% matrix K
Kft=zeros(Ndim1,nrad);
Kft(1,:)=0;
Kft(2,:)=-1i.*epsilon;
Kft(3,:)=-1i.*1.5.*epsilon.^2;

% matrix L
Ltmp=D;
Lft=zeros(Ndim1,nrad);
Lft(1,:)=(beta.*(1+epsilon.^2.*(3-2./q.^2))+...
    (1+epsilon.^2.*(0.5-1./q.^2))).*Ltmp;
Lft(2,:)=(2.*beta+1).*epsilon.*Ltmp;
Lft(3,:)=(2.5.*beta+0.75).*epsilon.^2.*Ltmp;

% matrix N
Ntmp=beta.*g.^2./D.*epsilon.^2;
% Ntmp=beta.*g./D.*epsilon.^2;
Nft=zeros(Ndim1,nrad);
Nft(1,:)=(2./(beta+1)).*Ntmp;
Nft(2,:)=(beta+2)./(beta+1).^2.*epsilon.*Ntmp;
Nft(3,:)=-(1./(beta+1)).*Ntmp;
Nft(4,:)=-(beta+2)./(beta+1).^2.*epsilon.*Ntmp;

%% Matrix A and B for solving, alcon_slover.F90
Omega=[];
for irad=1:nrad
%     irad=20; % test one radius point
    matA=zeros(Ndim); matB=zeros(Ndim);
    ilow=1; ihigh=Ndim;
    for i=ilow:ihigh
        nindex=1;
        if (finitebeta==2)
            % beta * G^dagger * M *G part in matA
            indices(nindex)=i;
            values(nindex)=beta(irad)*(n*q(irad)-(m1+i-1))^2/D(irad);
%             nindex=nindex+1;
            matA(i,indices(nindex))=values(nindex);

            nindex=1;
            for j=max(1,i-noffdiag):min(Ndim1,i+noffdiag)
              % L part in acs_matB
              indices(nindex)=j;
              if (j<i)
                values(nindex)=conj(Lft(i-j+1,irad));
              else
                values(nindex)=Lft(j-i+1,irad);
              end
              nindex=nindex+1;
            end
            matB(i,indices)=values;
        else
            if(i<=Ndim1)
                for j=max(1,i-noffdiag):min(Ndim1,i+noffdiag)
                    % G^dagger * H * G part in matA
                    indices(nindex)=j;
                    if(j<i)
                        values(nindex)=conj(Hft(i-j+1,irad));
                    else
                        values(nindex)=Hft(j-i+1,irad);
                    end
                    values(nindex)=values(nindex)*(n*q(irad)-(m1+i-1))*(n*q(irad)-(m1+j-1));                    
                    
                    % slow sound approximation, A = G^dagger * H * G part + N
                    if (finitebeta==1)
                      if (j<i)
                       values(nindex)=values(nindex)+conj(Nft(i-j+1,irad));
                      else
                       values(nindex)=values(nindex)+Nft(j-i+1,irad);
                      end
                    end
                    
                    nindex=nindex+1;
                    % -beta * K part in matA
                    if(finitebeta>2)
                        indices(nindex)=Ndim1+j;
                        if(j<i)
                         values(nindex)=-beta(irad)*conj(Kft(i-j+1,irad));
                        else
                         values(nindex)=-beta(irad)*Kft(j-i+1,irad);
                        end
                        nindex=nindex+1;
                    end
                end
                matA(i,indices)=values;

                % J part in acs_matB
                nindex=1;
                for j=max(1,i-noffdiag):min(Ndim1,i+noffdiag)
                    indices(nindex)=j;
                    if (j<i)
                        values(nindex)=conj(Jft(i-j+1,irad));
                    else
                        values(nindex)=Jft(j-i+1,irad);
                    end
                    nindex=nindex+1;
                end
                matB(i,indices)=values;
            else % i >= Ndim1+1, implies finitebeta > 2
                % beta * G^dagger * M * G part
                nindex=1;
                indices(nindex)=i;
                values(nindex)=beta(irad)*(n*q(irad)-(m1+(i-Ndim1)-1))^2/D(irad);
%                 nindex=nindex+1;
                matA(i,indices(nindex))=values(nindex);

                nindex=1;
                for j=max(Ndim1+1,i-noffdiag):min(Ndim,i+noffdiag)
                    % K part in matB
                    indices(nindex)=j-Ndim1;
                    if (j<i)
                        values(nindex)=conj(Kft(i-j+1,irad));
                    else
                        values(nindex)=Kft(j-i+1,irad);
                    end
                    nindex=nindex+1;

                    % L part in acs_matB
                    indices(nindex)=j;
                    if (j<i)
                        values(nindex)=conj(Lft(i-j+1,irad));
                    else
                        values(nindex)=Lft(j-i+1,irad);
                    end
                    nindex=nindex+1;
                end
                matB(i,indices)=values;
            end
        end
    end
    % solve the eigen matrix
    d=eig(matA,matB); % eigenvector here is not important for AW
    ind=find(abs(real(d))<100.*abs(imag(d)));
    d(ind)=NaN;
    omega=abs(real(sqrt(d./rho_M(irad))));
    Omega=[Omega;omega'];
end


% analytic solutions
for m=m1:m2
%     w_anal=abs((n.*q-m)./q).*va;
    w_anal=abs((n.*q-m)./q);
    subplot(2,2,ifbeta+1);plot(rho,w_anal,'c','LineWidth',1); hold on;
end

mw=length(omega);
for iw=1:mw
    subplot(2,2,ifbeta+1);plot(rho(1:end),Omega(:,iw),'r.','MarkerSize',5);
    ylim([0,1]); hold on;
end

xlabel('r/a'); ylabel('\omegaR_0/v_A');
str=['n=',num2str(n),', m=[',num2str(m1),',',num2str(m2),']',...
    ', ndiag=',num2str(noffdiag),', fbeta=',num2str(finitebeta)];
title(str);

end

runtime=cputime-runtime;
subplot(221); title(['Equlibrium, runtime=',num2str(runtime),'s']);

print(gcf,'-dpng',['n=',num2str(n),',m=[',num2str(m1),',',...
    num2str(m2),']',',noffdiag=',num2str(noffdiag),...
    ',eq=',num2str(eq),'.png']);

