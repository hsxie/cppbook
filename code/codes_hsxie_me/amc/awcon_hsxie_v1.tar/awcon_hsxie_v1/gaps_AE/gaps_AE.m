% Hua-sheng XIE, IFTS-ZJU, huashengxie@gmail.com, 2013-01-23 21:32
% gaps_AE.m, plot Tokamak shear Alfven wave gaps using analytical solution
% [1] Fu, G. Y. and Dam, J. W. V., Physics of Fluids B, 1989, 1, 1949-1952.
% [2] Vlad, G., Zonca, F. and Briguglio, S., Dynamics of Alfven waves in
% tokamaks, 1999.
% [3] Wang, X.; Zonca, F. & Chen, L., PPCF, 2010, 52, 115005.
% Rewritten from Andreas Bierwage and Long-yu QI's versions
close all; clear; clc;
eq=1;
x=0.0:0.001:1.0;
if(eq==1) % Wang2010
    R=10;
    n=3;
    q=2.7+(3.9-2.7)*x.^2;
    va=0.*x+1;
elseif(eq==2) % Fu1989
    R=4;
    n=-1; 
    q=1.0+x.^2;
    va=0.*x+1;
else
    R=4;
    n=3;
    q=0.95-x+4*x.^2-1.0*x.^3;
    va=1.0.*(1+x/R)./sqrt(exp(-x.^2));    
end
sgm=3/(2*R); % sgm=3a/2R in [Fu1989]
    
for ix=1:length(x)
    m=floor(q(ix)*n);
    ml=m;
    mu=ml+1;
    km=(n-m/q(ix))/R; km1=(n-(m+1)/q(ix))/R;
    kmva2=(km*va(ix))^2;km1va2=(km1*va(ix))^2;
    sgmx2=(sgm*x(ix))^2;
    wt1=sqrt((kmva2+km1va2+sqrt((kmva2-km1va2)^2+...
        4.0*(sgmx2*kmva2*km1va2)))/(2.0*(1.0-sgmx2)));
    wt2=sqrt((kmva2+km1va2-sqrt((kmva2-km1va2)^2+...
        4.0*(sgmx2*kmva2.*km1va2)))/(2.0*(1.0-sgmx2)));
    wtl(ix)=(wt1>=wt2)*wt2+(wt2>wt1)*wt1;
    wtu(ix)=(wt2>=wt1)*wt2+(wt1>wt2)*wt1;
    
    pltx(2*ix-1)=x(ix); pltx(2*ix)=x(ix); % for scatter plot
    plty(2*ix-1)=wtl(ix); plty(2*ix)=wtu(ix);
    pltc(2*ix-1)=(q(ix)>=(2*m+1)/(2*n))*mu+(q(ix)<(2*m+1)/(2*n))*ml;
    pltc(2*ix)=(q(ix)>=(2*m+1)/(2*n))*ml+(q(ix)<(2*m+1)/(2*n))*mu;
    
    wc1=abs(km*va(ix));
    wc2=abs(km1*va(ix));
    wcl(ix)=(wc1>=wc2)*wc2+(wc2>wc1)*wc1;
    wcu(ix)=(wc2>=wc1)*wc2+(wc1>wc2)*wc1;
end
norm=va(1)/R; % normalization const.
wtl=wtl/norm; wtu=wtu/norm; wcl=wcl/norm; wcu=wcu/norm;
plty=plty/norm;

figure('Unit','Normalized','Position',[0.01 0.4 0.5 0.5]);
set(gcf,'DefaultAxesFontSize',15);

subplot(221); plot(x,q,x,va,'LineWidth',2);
legend('q','v_A'); legend('boxoff');
ylim([0, 1.2*max(max(q),max(va))]);
xlabel('r/a'); title(['Equilibrium profile, R/a=',num2str(R)]);

subplot(222);plot(x,wtl,'r',x,wtu,'r',x,wcl,'g:',...
    x,wcu,'g:','LineWidth',2);
xlabel('r/a');ylabel('\omega/(v_A(0)/R_0)');
title(['Alfven continua spectrum, n=',num2str(n)]);

subplot(223); h=scatter(pltx,plty,5,pltc,'filled');
xlabel('r/a'); box on;
title(['m=[',num2str(min(pltc)),',',num2str(max(pltc)),']']);
% legend(h,'m=1','m=2','m=3');

% add BAE gap
betai=0.0072; tau=0.0001;
wbtu=sqrt(wtu.^2+(7/4+tau)*betai); % need check, q
wbtl=sqrt(wtl.^2+(7/4+tau)*betai);
wbcu=sqrt(wcu.^2+(7/4+tau)*betai);
wbcl=sqrt(wcl.^2+(7/4+tau)*betai);
subplot(224);plot(x,wbtl,'m',x,wbtu,'m',x,wbcl,'c:',...
    x,wbcu,'c:','LineWidth',2);
xlabel('r/a');ylabel('\omega/(v_A(0)/R_0)');
% ylim([0 1]);
title(['With BAE, \beta_i=',num2str(betai),', T_e/T_i=',num2str(tau)]);

print('-dpng',['gaps_AE,eq=',num2str(eq),'.png']);
