Alfven wave continuum spectral solvers

1. AWCON.m (numerical), calculate ideal MHD Alfven Wave CONtinuum spectral in
  tokamak
2. gaps_AE.m (analytical), plot Tokamak shear Alfven wave gaps using analytical
  solution

gaps_AE.m is easy to understand, one can refer [Fu1989] for the formula. The 
eigenmode (AEs) solutions have not been solved here.

AWCON.m is more complicate. For this version (v1), it is just a rewriting of 
Wen-jun DENG's ALCON, and only contains the analytical equilibrium. So, you 
can read Wenjun's ALCON code and document (thesis, NF2012 papers) for details.


I write this version (v1) as short as possible to show how to calculate Alfven 
wave continuum spectral. If you are an Alfven wave researcher or beginner, this 
version is enough to provide a guide for you to develop your own codes.

I will update these solvers for more general and pratical cases if I have time.


[1] Fu, G. Y. and Dam, J. W. V., Physics of Fluids B, 1989, 1, 1949-1952.
[2] Wenjun's ALCON, http://wdeng.info/

Hua-sheng XIE (IFTS-ZJU)
huashengxie@gmail.com
2013-06-02 13:10