Linear (both intial value and eigenvalue solvers) tearing mode solution in 2D reduced MHD equation

a. Slab 2D

b. Cylinder

I just wrote them (in 2013) but have never used them for my own projects. For several benchmark cases, they agree with other people's results very well. However, you should be careful to use them, unless you have understood the equations and the codes.

The cylinder version has been used with update in [Liu2015].

Cite:
[Liu2015] Dongjian Liu, Wenlu Zhang, Joseph McClenaghan, Jiaqi Wang, and Zhihong Lin, Verification of gyrokinetic particle simulation of current-driven instability in fusion plasmas. II. Resistive tearing mode, Physics of Plasmas 21, 122520 (2014).


20:48 2015/3/20 