% Hua-sheng XIE, IFTS-ZJU, huashengxie@gmail.com, 2012-12-27 15:11
% Orbit.m, particle orbit in Tokamak, see also OrbitGC.m
% without E field. relativistic part here is not general
% Energy not conserved and independent on dt? Strange.

function Orbit_tokamak
    close all; clear; clc;

    global q m rel Bfield Efield;
    global B0 R0;
    
    rel=0; % rel=1, relativistic else non-relativistic

    % Parameters
    e = 1.602176565e-19; % Elementary charge (Coulomb)
    m_pr = 1.672621777e-27; % Proton mass (kg)
    m_el = 9.10938291e-31; % Electron mass (kg)
    c = 299792458; % speed of light (m/s)
    
    m=m_pr;

    % Defintions for different E and B fields
    Ezero=@(x,y,z,t)[0,0,0];
    Efield=@(x,y,z,t)Ezero(x,y,z,t);
    rr=@(x,y,z,t)sqrt((sqrt(x^2+y^2)-R0)^2+z^2)+1e-10;
    qq=@(x,y,z,t)1.0+rr(x,y,z,t)^2; % q profile
%     qq=@(x,y,z,t)4.0; % q profile
%     Bt=@(x,y,z,t)B0/sqrt(1+rr(x,y,z,t)^2/(qq(x,y,z,t)*R0)^2);
%     Bp=@(x,y,z,t)B0/sqrt(1+(qq(x,y,z,t)*R0)^2/rr(x,y,z,t)^2); % not correct
    Bt=@(x,y,z,t)B0*R0/sqrt(x^2+y^2);
    Bp=@(x,y,z,t)Bt(x,y,z,t)*rr(x,y,z,t)/(qq(x,y,z,t)*R0);
    Btkmkx=@(x,y,z,t)(-Bt(x,y,z,t)*(y/sqrt(x^2+y^2))-Bp(x,y,z,t)*(z/rr(x,y,z,t))*(x/sqrt(x^2+y^2)));
    Btkmky=@(x,y,z,t)(Bt(x,y,z,t)*(x/sqrt(x^2+y^2))-Bp(x,y,z,t)*(z/rr(x,y,z,t))*(y/sqrt(x^2+y^2)));
%     Btkmkz=@(x,y,z,t)(Bp(x,y,z,t)*(sqrt(rr(x,y,z,t)^2-z^2)/rr(x,y,z,t)));% not correct, only +
    Btkmkz=@(x,y,z,t)(Bp(x,y,z,t)*((sqrt(x^2+y^2)-R0)/rr(x,y,z,t)));
    BBtkmk=@(x,y,z,t)sqrt(Btkmkx(x,y,z,t)^2+Btkmky(x,y,z,t)^2+Btkmkz(x,y,z,t)^2);
    Btokamak=@(x,y,z,t)[Btkmkx(x,y,z,t),Btkmky(x,y,z,t),Btkmkz(x,y,z,t)];

    B0=1.0; R0=3.0; m=m_pr; q=e;
    Bfield=@(x,y,z,t)Btokamak(x,y,z,t);

    % Initial and Calculating
    type=3;
    if(type==1) % Trajectory of a proton with 1 MeV kinetic energy        
        K0=1e6; % kinetic energy in eV
        x0=(1.0+0.2)*R0; y0=0*R0; z0=0*R0;
        pitch_angle=85.0; % initial angle between velocity and mag.field (degrees)
    elseif(type==2)
        K0=2e4; % kinetic energy in eV
        x0=(1.0+0.4)*R0; y0=0*R0; z0=0*R0;
        pitch_angle=60.0;
    else
        K0=2e5; % kinetic energy in eV
        x0=1.2*R0; y0=0*R0; z0=0*R0;
        pitch_angle=20.0;
    end
    K=K0*e  ; % convert to Joule
%     v=c/sqrt(1+(m*c^2)/K);
    v=sqrt(K/m);
    drc=-1; % change direction of vpara or (vx,vy,vz)
    vpara0=v*cos(pitch_angle*pi/180);
    vpara0=drc*vpara0; % +/- neoclassical collison shift of banana center
    vperp0=v*sin(pitch_angle*pi/180);
    Btkmkx0=Btkmkx(x0,y0,z0,0);Btkmky0=Btkmky(x0,y0,z0,0);
    Btkmkz0=Btkmkz(x0,y0,z0,0);BBtkmk0=BBtkmk(x0,y0,z0,0);
    
    vx0=(vpara0*Btkmkx0+vperp0*Btkmkx0*Btkmkz0/sqrt(Btkmkx0^2+Btkmky0^2))/BBtkmk0;
    vy0=(vpara0*Btkmky0+vperp0*Btkmky0*Btkmkz0/sqrt(Btkmkx0^2+Btkmky0^2))/BBtkmk0;
    vz0=(vpara0*Btkmkz0-vperp0*sqrt(Btkmkx0^2+Btkmky0^2))/BBtkmk0;
    
%     vx0=drc*vx0;vy0=drc*vy0;vz0=drc*vz0; % classical collison?
    
    T=2*pi*m/(abs(q)*B0);
    dt=T/16;
    tend=800*T;

    yy0=[x0,y0,z0,vx0,vy0,vz0];
    [t,y]=ode45(@orbit,0:dt:tend,yy0);
    xx=y(:,1);yy=y(:,2);zz=y(:,3);vxx=y(:,4);vyy=y(:,5);vzz=y(:,6);
    rr=sqrt((sqrt(xx.^2+yy.^2)-R0).^2+zz.^2);
    aa=min(1.2*max(rr),0.5*R0);
    EE=(vxx.^2+vyy.^2+vzz.^2)*m/e;
    
    % Plot
    figure; set(gcf,'DefaultAxesFontSize',15);
    subplot(221);plot3(x0,y0,z0,'o'); hold on;
    plot3(xx,yy,zz,'r');
    xlabel('x');ylabel('y');zlabel('z');hold on;    
    v0=sqrt(vx0^2+vy0^2+vz0^2);
    quiver3(x0,y0,z0,vx0/v0,vy0/v0,vz0/v0,1.5);
    title(['R0=',num2str(R0),'m, E=',num2str(K/e/1e3),'keV']);
    [u,v]=meshgrid(0:2*pi/50:2*pi,0:2*pi/50:1.5*pi);
    X=(R0+aa.*cos(u)).*cos(v); Y=(R0+aa.*cos(u)).*sin(v);
    Z=aa.*sin(u); mesh(X,Y,Z);axis equal;hidden off;colormap([0 1 1]);
    
    subplot(222);plot(sqrt(y(:,1).^2+y(:,2).^2)-R0,y(:,3),'.');
    xlabel('r');ylabel('Z'); title('poloidal projection'); hold on;
    plot(aa.*cos(0:pi/20:2*pi),aa.*sin(0:pi/20:2*pi),'r--'); axis equal;
%     xlim([-aa,aa]); ylim([-aa,aa]);

    subplot(223); plot(t,EE,'r','LineWidth',2); title('Energy');
    xlabel('t'); ylabel('E'); xlim([0,max(t)]);

    print(gcf,'-dpng',['E=',num2str(K0/1000),'KeV,R0=',num2str(R0),'m,r0=',...
    num2str(sqrt(x0^2+y0^2)-R0),'m,angle=',num2str(pitch_angle),...
    ',drc=',num2str(drc),'.png']);
end

function dy=orbit(t,y)
    global  q rel m Bfield Efield;
    
    dy=zeros(6,1);
    vsq = y(4)^2 + y(5)^2 + y(6)^2;
    
    if (rel==1) % relativistic factor
        gamma = 1.0/sqrt(1 - vsq/c^2);
    else % non-relativistic
        gamma=1;
    end
    
    Bvec = Bfield(y(1),y(2),y(3),t);
    Bx=Bvec(1);By=Bvec(2);Bz=Bvec(3);
    Evec=Efield(y(1),y(2),y(3),t);
    Ex=Evec(1);Ey=Evec(2);Ez=Evec(3);
    
    fac=q/(m*gamma);
    dy=[y(4);y(5);y(6);
       fac*(Ex+Bz*y(5)-By*y(6));
       fac*(Ey+Bx*y(6)-Bz*y(4));
       fac*(Ez+By*y(4)-Bx*y(5))];
end