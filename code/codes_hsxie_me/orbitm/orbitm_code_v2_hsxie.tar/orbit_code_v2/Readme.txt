1. orbit_general
Orbit.m, single particle motion for: space plasma (current sheet, dipole, ...), Tokamak, Laser, ...

A short code, but can treat almost all the common particle motion problems in different EM fields.

2. tokamak
Orbit_tokamak: Using Lorentz force, with gyro. Rewritten from "Orbit.m".
OrbitGC_qfix: Guiding center orbit with q=const.
OrbitGC_qpsip: Guiding center orbit with q=q1+q2*psip+q3*psip^2.
See "OrbitTokamak_doc.doc" for related formula.

Hua-sheng XIE (huashengxie@gmail.com)
10:32 2012-12-28